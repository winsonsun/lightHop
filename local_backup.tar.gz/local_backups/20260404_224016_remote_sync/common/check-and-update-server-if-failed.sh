#!/bin/bash

#
# Example: ./check-and-update-server-if-failed.sh -q B -s /etc/effective-tunnel/conf/server-conf-aws.json -d /etc/effective-tunnel/conf/server-conf-aws.json
#

__VERBOSE=7

SHELL_FOLDER=$(dirname $(readlink -f "$0"))
WORKDIR=$(dirname $SHELL_FOLDER)

src_conf_file="/etc/effective-tunnel/conf/server-conf-aws.json"
dst_conf_file="/etc/effective-tunnel/conf/server-conf-aws.json"

quick_apply="A"
proxy_ip="127.0.0.1"

restart_service() {
    local service_name="$1"
    if sudo systemctl is-enabled --quiet "$service_name"; then
        echo "Restarting $service_name"
        sudo systemctl restart "$service_name"
    else
        echo "$service_name is not enabled"
    fi
}

while getopts s:d:e:p:q:v: flag
do
    case "${flag}" in
        s) src_conf_file=${OPTARG};;
        d) dst_conf_file=${OPTARG};;
        p) quick_apply=${OPTARG};;
        q) quick_apply=${OPTARG};;
        v) __VERBOSE=${OPTARG};;
    esac
done
server_port=$( cat $src_conf_file | jq -r '.server_port' )
local_port=$( cat $src_conf_file | jq -r '.local_port' )

if [[ ! $( curl --connect-timeout 10 --proxy "socks5h://${proxy_ip}:${local_port}" "https://www.google.com" ) ]]; then
#if [[ 1 -gt 0 ]]; then
  echo "ERROR: Proxy is NOT running normally. Starting diagnostic procedure."
  
  result_file_name="log.txt"
  exec > >(tee "$HOME/$result_file_name") 2>&1

  #ssh -i ~/.ssh/id_rsa root@8.134.194.115 workspace/projects/keyin/common/dummysk.sh -h "${server_ip}" -u ubuntu -p "${server_port}"
  #new_server_ip=$( cat "$HOME/${result_file_name}" | grep "new_server_ip" | cut -d "=" -f 2 | jq -r '.new_server_ip' )

  new_server_ip="no_where"

  echo 00

  if [[ "${quick_apply}" == "A" ]] 
  then 
    echo 01
    ssh -i ~/.ssh/id_rsa root@8.134.194.115 'workspace/projects/keyin/common/libs/updateip -o Y' > update_ip.txt
    new_server_ip=$( cat update_ip.txt )
  elif [[ "${quick_apply}" == "B" ]]; then 
    ssh -i ~/.ssh/id_rsa root@8.134.194.115 'workspace/projects/keyin/common/libs/updateip' > update_ip.txt
    new_server_ip=$( cat update_ip.txt )
  elif [[ "${quick_apply}" == "C" ]]; then 
    ssh -i ~/.ssh/id_rsa root@8.134.194.115 'workspace/projects/keyin/common/dummysk.sh -h "${server_ip}" -u ubuntu -p "${server_port}"'
    new_server_ip=$( cat "$HOME/${result_file_name}" | grep "new_server_ip" | cut -d "=" -f 2 | jq -r '.new_server_ip' )
  fi 

  echo 10
  echo new_server_ip "${new_server_ip}"

  if [[ "${new_server_ip}" == "no_where" ]]; then
    echo "Cannot find valid new_server_ip, exit"
    exit 10
  fi

  if [ ${#new_server_ip} -gt 0 ]; then 
    echo new_server_ip: "${new_server_ip}"
    sudo "${SHELL_FOLDER}"/change-server-ip.sh "${new_server_ip}" "${dst_conf_file}"

    if [[ $OSTYPE == 'darwin'* ]]; then
      echo 'macOS'
      sudo launchctl unload /Library/LaunchAgents/shell.ss-local.plist && sudo launchctl load /Library/LaunchAgents/shell.ss-local.plist
    elif [[ $OSTYPE == 'linux'* ]]; then
      echo 'linux'

      services=( "dnscrypt-proxy" "ss-tproxy" )

      for service in "${services[@]}"; do
        restart_service "$service"
	sleep 1
      done      
    fi
  fi 
else
  echo "STATUS: Proxy is running normally"
fi

