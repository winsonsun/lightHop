#!/bin/bash
# example: ./change-server-ip.sh 1.1.1.1 /etc/effective-tunnel/conf/server-conf-aws.json
function replaceappend() {
    awk -v old=".*$2.*" -v new="$3" '                                                                                                        
        sub(old,new) { replaced=1 }                                                                                                         
        { print }                                                                                                                           
        END { if (!replaced) print new }                                                                                                    
    ' "$1" > /tmp/tmp$$ &&
    mv /tmp/tmp$$ "$1"
}

function replace_find_with_line() {
	awk -vold="$2" -vnew="$3" 'index($0,old)==1{f=1;$0=new}1;END{if(!f)print new}' "$1"
}

export server_ip="$1"

echo $server_ip

replaceappend "$2" "\"server\"" "    \"server\": \"${server_ip}\","
